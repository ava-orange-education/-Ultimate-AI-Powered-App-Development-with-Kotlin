package com.orangeava.composableexamples.asynchronous

// This sealed class represents the different states of our UI.
// This is a key part of the reactive pattern in Compose.
sealed class UiState {
    object Idle : UiState()
    object Loading : UiState()
    data class Success(val result: AiOutput) : UiState()
    data class Error(val message: String) : UiState()
}
