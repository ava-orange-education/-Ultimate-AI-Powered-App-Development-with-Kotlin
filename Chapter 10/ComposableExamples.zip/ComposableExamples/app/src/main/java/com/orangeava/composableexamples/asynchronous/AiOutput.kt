package com.orangeava.composableexamples.asynchronous

// A simple data class to hold the AI's output.
// This would contain the prediction, confidence, and any other relevant data.
data class AiOutput(val prediction: String, val confidence: Float)
