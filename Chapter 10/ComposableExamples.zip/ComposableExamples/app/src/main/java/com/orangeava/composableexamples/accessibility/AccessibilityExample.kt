package com.orangeava.composableexamples.accessibility

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.orangeava.composableexamples.R
import com.orangeava.composableexamples.animation.AiFeedbackScreen
import com.orangeava.composableexamples.asynchronous.AiOutput
import com.orangeava.composableexamples.asynchronous.UiState

@Composable
fun AiImage(
    aiOutput: AiOutput,
    modifier: Modifier = Modifier
) {
    Image(
        painter = painterResource(id = R.drawable.book),
        contentDescription = null, // Set to null as we'll use semantics
        modifier = modifier.semantics {
            contentDescription = aiOutput.prediction
        }
    )
}

@Composable
fun RealTimePrediction(prediction: String) {
    Box(
        modifier = Modifier.semantics {
            liveRegion = LiveRegionMode.Polite
        }
    ) {
        Text(text = "New prediction: $prediction")
    }
}


@Preview(showBackground = true)
@Composable
fun PreviewAiImage() {
    // Fake AI result
    val aiOutput = AiOutput(
        prediction = "Dog",
        confidence = 0.95f
    )

    // Use AiImage with some styling
    AiImage(
        aiOutput = aiOutput,
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .padding(16.dp)
    )
}

@Preview(showBackground = true)
@Composable
fun PreviewRealTimePrediction() {
    RealTimePrediction("Prediction")
}