package com.orangeava.composableexamples.animation

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.orangeava.composableexamples.asynchronous.AiOutput
import com.orangeava.composableexamples.asynchronous.AiResultCardUpdated
import com.orangeava.composableexamples.asynchronous.UiState

@Composable
fun AiFeedbackScreen(uiState: UiState) {
    Crossfade(
        targetState = uiState,
        label = "AI Feedback Crossfade"
    ) { state ->
        when (state) {
            UiState.Idle -> Placeholder()
            UiState.Loading -> LoadingIndicator()
            is UiState.Success -> AiResultCardUpdated(state.result)
            is UiState.Error -> ErrorView(state.message)
        }
    }
}

@Composable
fun LoadingIndicator() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator()
    }
}

@Composable
fun Placeholder() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "Waiting for input...",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.Gray
        )
    }
}

@Composable
fun ErrorView(message: String = "Something went wrong") {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = Color.Red,
            textAlign = TextAlign.Center
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewLoading() {
    AiFeedbackScreen(UiState.Loading)
}

@Preview(showBackground = true)
@Composable
fun PreviewSuccess() {
    AiFeedbackScreen(UiState.Success(AiOutput("Dog", 0.95f)))
}

@Preview(showBackground = true)
@Composable
fun PreviewError() {
    AiFeedbackScreen(UiState.Error("Unknown Error"))
}

@Preview(showBackground = true)
@Composable
fun PreviewIdle() {
    AiFeedbackScreen(UiState.Idle)
}