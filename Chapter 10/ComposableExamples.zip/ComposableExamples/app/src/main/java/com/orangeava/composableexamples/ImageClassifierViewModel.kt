package com.orangeava.composableexamples

import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.orangeava.composableexamples.asynchronous.AiOutput
import com.orangeava.composableexamples.asynchronous.UiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

// ViewModel for our Image Classifier.
// It manages the UI state and runs the AI inference on a background thread.
class ImageClassifierViewModel : ViewModel() {
    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState

    // Placeholder for the AI model. In a real app, this would be an instance
    // of your LiteRT engine.
    private val aiModel = object {
        fun runInference(bitmap: Bitmap): AiOutput {
            // Simulate a long-running inference process
            Thread.sleep(2000)
            // Return a dummy result
            return AiOutput("Dog", 0.95f)
        }
    }

    fun classifyImage(bitmap: Bitmap) {
        viewModelScope.launch(Dispatchers.Default) {
            _uiState.value = UiState.Loading
            try {
                val result = aiModel.runInference(bitmap)
                _uiState.value = UiState.Success(result)
            } catch (e: Exception) {
                _uiState.value = UiState.Error(
                    e.message ?: "An unknown error occurred."
                )
            }
        }
    }
}

// The main screen composable that observes the
// ViewModel's state and updates the UI.
@Composable
fun ImageClassifierScreen(
    viewModel: ImageClassifierViewModel,
    // Placeholder for the image to be classified.
    // In a real app, this would come from a camera or photo picker.
    imageToClassify: Bitmap?
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Display the image if available
        if (imageToClassify != null) {
            Image(
                bitmap = imageToClassify.asImageBitmap(),
                contentDescription = "Image to classify",
                modifier = Modifier.size(250.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Show different UI based on the current state
        when (uiState) {
            is UiState.Idle -> {
                Text("Tap the button to start classification.")
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = {
                    if (imageToClassify != null) {
                        viewModel.classifyImage(imageToClassify)
                    }
                }) {
                    Text("Classify Image")
                }
            }

            is UiState.Loading ->
                CircularProgressIndicator(modifier = Modifier.size(64.dp))

            is UiState.Success ->
                AiResultCard(result = (uiState as UiState.Success).result)

            is UiState.Error ->
                Text("Error: ${(uiState as UiState.Error).message}")
        }
    }
}

// A reusable composable card to display the AI's output.
// This is the AIResultCard you mentioned.
@Composable
fun AiResultCard(result: AiOutput) {
    Card(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Prediction: ${result.prediction}",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Confidence: ${"%.2f".format(result.confidence * 100)}%",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

// A simple preview composable
@Preview(showBackground = true)
@Composable
fun PreviewImageClassifierScreen() {
    MaterialTheme {
        ImageClassifierScreen(
            viewModel = ImageClassifierViewModel(),
            imageToClassify = null // For preview, we don't have a real bitmap
        )
    }
}

