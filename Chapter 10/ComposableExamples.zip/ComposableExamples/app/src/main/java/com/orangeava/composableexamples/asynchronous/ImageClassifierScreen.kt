package com.orangeava.composableexamples.asynchronous

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProgressIndicatorDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.orangeava.composableexamples.ImageClassifierViewModel

// The main screen composable that observes the ViewModel's state and updates the UI.
@Composable
fun ImageClassifierScreen(
    viewModel: ImageClassifierViewModel,
    // Placeholder for the image to be classified.
    // In a real app, this would come from a camera or photo picker.
    imageToClassify: Bitmap?
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Display the image if available
        if (imageToClassify != null) {
            Image(
                bitmap = imageToClassify.asImageBitmap(),
                contentDescription = "Image to classify",
                modifier = Modifier.size(250.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Show different UI based on the current state
        when (uiState) {
            is UiState.Idle -> {
                Text("Tap the button to start classification.")
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = {
                    if (imageToClassify != null) {
                        viewModel.classifyImage(imageToClassify)
                    }
                }) {
                    Text("Classify Image")
                }
            }

            is UiState.Loading -> CircularProgressIndicator(modifier = Modifier.size(64.dp))
            is UiState.Success -> AiResultCard(result = (uiState as UiState.Success).result)
            is UiState.Error -> Text("Error: ${(uiState as UiState.Error).message}")
        }
    }
}

// A reusable composable card to display the AI's output.
// This is the AIResultCard you mentioned.
@Composable
fun AiResultCard(result: AiOutput) {
    Card(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Prediction: ${result.prediction}",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Confidence: ${"%.2f".format(result.confidence * 100)}%",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}


@Composable
fun AiResultCardUpdated(result: AiOutput) {
    // Define a color that changes based on confidence
    val confidenceColor = when {
        result.confidence > 0.8f ->
            Color(0xFF4CAF50) // High confidence (Green)
        result.confidence > 0.5f ->
            Color(0xFFFFC107) // Medium confidence (Amber)
        else ->
            Color(0xFFF44336) // Low confidence (Red)
    }

    Card(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Prediction: ${result.prediction}",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Display a warning icon for low confidence
                if (result.confidence < 0.5f) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Low Confidence",
                        tint = confidenceColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Visualize confidence with a CircularProgressIndicator
                CircularProgressIndicator(
                    progress = { result.confidence },
                    color = confidenceColor,
                    modifier = Modifier.size(24.dp),
                    strokeCap = ProgressIndicatorDefaults.CircularIndeterminateStrokeCap
                )
                Text(
                    text = "Confidence: ${"%.2f".format(result.confidence * 100)}%",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

// A simple preview composable
@Preview(showBackground = true)
@Composable
fun PreviewImageClassifierScreen() {
    MaterialTheme {
        ImageClassifierScreen(
            viewModel = ImageClassifierViewModel(),
            imageToClassify = null // For preview, we don't have a real bitmap
        )
    }
}