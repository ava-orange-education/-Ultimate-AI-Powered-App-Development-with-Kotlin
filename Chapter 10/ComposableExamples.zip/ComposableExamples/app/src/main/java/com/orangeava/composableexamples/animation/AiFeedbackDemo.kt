package com.orangeava.composableexamples.animation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.tooling.preview.Preview
import com.orangeava.composableexamples.asynchronous.AiOutput
import com.orangeava.composableexamples.asynchronous.AiResultCardUpdated
import com.orangeava.composableexamples.asynchronous.UiState
import com.orangeava.composableexamples.ui.theme.ComposableExamplesTheme
import kotlinx.coroutines.delay

@Composable
fun AiScreenDemo() {
    // Simulating UI state (in real apps, this comes from ViewModel)
    var uiState by remember { mutableStateOf<UiState>(UiState.Loading) }

    // Fake delayed state change
    LaunchedEffect(Unit) {
        delay(2000)  // show loading for 2 seconds
        uiState = UiState.Success(AiOutput("Dog", 0.95f))
        // Uncomment below to test error
        // uiState = UiState.Error("Something went wrong")
    }

    // Use the composable
    AiFeedbackScreen(uiState)
}

/*
@Preview(showBackground = true)
@Composable
fun PreviewLoading() {
    AiFeedbackScreen(UiState.Loading)
}

@Preview(showBackground = true)
@Composable
fun PreviewSuccess() {
    AiFeedbackScreen(UiState.Success(AiOutput("Dog", 0.95f)))
}

@Preview(showBackground = true)
@Composable
fun PreviewError() {
    AiFeedbackScreen(UiState.Error("Unknown Error"))
}

@Preview(showBackground = true)
@Composable
fun PreviewIdle() {
    AiFeedbackScreen(UiState.Idle)
}*/
