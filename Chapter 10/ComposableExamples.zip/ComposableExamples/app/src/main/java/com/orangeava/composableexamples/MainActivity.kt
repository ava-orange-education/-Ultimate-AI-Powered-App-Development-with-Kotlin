package com.orangeava.composableexamples

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.orangeava.composableexamples.animation.AiScreenDemo
import com.orangeava.composableexamples.asynchronous.AiOutput
import com.orangeava.composableexamples.asynchronous.AiResultCardUpdated
import com.orangeava.composableexamples.ui.theme.ComposableExamplesTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ComposableExamplesTheme {
                val image = ImageBitmap.imageResource(id = R.drawable.book)
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    /*AiPredictionText(prediction = "Prediction: CAR 90%")*/
                    /*AiTriggerButton(
                        onAnalyzeClick = {
                            Log.d("MainActivity", "Button clicked!")
                        },
                    )*/

                    /*AiImageOutput(imageBitmap = image)*/

                    // CircularProgressIndicator()
                    exampleOfColumnLayout()
                }
            }
        }
    }
}

@Composable
fun AiPredictionText(prediction: String) {
    Text(
        text = "Prediction: $prediction",
        style = androidx.compose.material3.MaterialTheme.typography.titleMedium
    )
}

@Composable
fun AiTriggerButton(onAnalyzeClick: () -> Unit) {
    Button(onClick = onAnalyzeClick) {
        Text("Analyze")
    }
}

@Composable
fun AiImageOutput(imageBitmap: ImageBitmap) {
    Image(
        bitmap = imageBitmap,
        contentDescription = "Output from AI model"
    )
}

@Composable
fun LoadingIndicator() {
    CircularProgressIndicator(
        modifier = Modifier.size(48.dp),
        color = androidx.compose.material3.MaterialTheme.colorScheme.primary
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    ComposableExamplesTheme {
        // CircularProgressIndicator()
        // exampleOfRowLayout()
        // exampleOfColumnLayout()
        // exampleOfBoxLayout()
        // AiResultCardUpdated(AiOutput("Dog", 0.65f))

        AiScreenDemo()
    }
}

@Composable
fun exampleOfRowLayout() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Hello",
            style = androidx.compose.material3.MaterialTheme.typography.bodyLarge
        )
        Button(onClick = { /* Handle click */ }) {
            Text("Action")
        }
    }
}

@Composable
fun exampleOfColumnLayout() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.LightGray.copy(alpha = 0.3f))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "AI is thinking...",
            style = androidx.compose.material3.MaterialTheme.typography.titleMedium
        )
        CircularProgressIndicator(
            modifier = Modifier.size(48.dp),
            color = androidx.compose.material3.MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
fun exampleOfBoxLayout() {
    Box(
        modifier = Modifier
            .size(200.dp)
            .background(Color.Gray),
        contentAlignment = Alignment.Center
    ) {
        // A placeholder for a visual AI output
        Image(
            painter = painterResource(id = R.drawable.cat),
            contentDescription = "Image placeholder",
            modifier = Modifier.fillMaxSize(), // fills the entire box
            contentScale = ContentScale.FillBounds // stretches in both directions
        )

        // A text overlay on top of the image
        Text(
            text = "Prediction: Cat",
            modifier = Modifier
                .background(Color.Black.copy(alpha = 0.5f))
                .padding(8.dp)
                .align(Alignment.BottomCenter),
            color = Color.White,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun BasicLayoutsAndComponents() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Example of a Row layout
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Hello", style = androidx.compose.material3.MaterialTheme.typography.bodyLarge)
            Button(onClick = { /* Handle click */ }) {
                Text("Action")
            }
        }


        // Example of a Column layout with essential components
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.LightGray.copy(alpha = 0.3f))
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = "AI is thinking...", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
            CircularProgressIndicator(
                modifier = Modifier.size(48.dp),
                color = androidx.compose.material3.MaterialTheme.colorScheme.primary
            )
        }

        // Example of a Box layout for overlapping content
        Box(
            modifier = Modifier
                .size(200.dp)
                .background(Color.Gray),
            contentAlignment = Alignment.Center
        ) {
            // A placeholder for a visual AI output
            Image(
                painter = painterResource(id = R.drawable.ic_launcher_background),
                contentDescription = "AI generated image placeholder",
                modifier = Modifier.size(150.dp)
            )


            // A text overlay on top of the image
            Text(
                text = "Prediction: Cat",
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(8.dp)
                    .align(Alignment.BottomCenter),
                color = Color.White,
                textAlign = TextAlign.Center
            )
        }
    }
}
