package com.orangeava.contextualaiassistant.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun MainTabScreen() {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Gemini", "ChatGPT")

    Scaffold(
        topBar = {
            TabRow(selectedTabIndex = selectedTabIndex) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(title) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding)) {
            when (selectedTabIndex) {
                0 -> {
                    // TAB 1: For Gemini
                    ChatScreen(
                        viewModel = viewModel(
                            key = "gemini_vm",
                            factory = ChatViewModelFactory(ModelType.Gemini)
                        )
                    )
                }

                1 -> {
                    // TAB 2: For ChatGPT
                    ChatScreen(
                        viewModel = viewModel(
                            key = "chatgpt_vm",
                            factory = ChatViewModelFactory(ModelType.ChatGPT)
                        )
                    )
                }
            }
        }
    }
}
