package com.orangeava.contextualaiassistant.data

import android.graphics.Bitmap
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.orangeava.contextualaiassistant.domain.AiRepository

class GeminiRepository(apiKey: String) : AiRepository {

    // Initialize the model. 'flash' is faster and cheaper.
    private val model = GenerativeModel(
        modelName = "gemini-2.5-flash-lite",
        apiKey = apiKey
    )

    // Conversational Memory: This object keeps track of the history automatically.
    private val chat = model.startChat()

    override suspend fun sendMessage(prompt: String, imageBitmap: Any?): String {
        return try {
            if (imageBitmap != null && imageBitmap is Bitmap) {
                // --- Contextual Response (Image + Text) ---
                // We use generateContent() for single-turn image queries
                val input = content {
                    image(imageBitmap)
                    text(prompt)
                }
                val response = model.generateContent(input)
                response.text ?: "No response"
            } else {
                // --- Conversational Response (Text History) ---
                // We use chat.sendMessage() to maintain history
                val response = chat.sendMessage(prompt)
                response.text ?: "No response"
            }
        } catch (e: Exception) {
            "Error: ${e.localizedMessage}"
        }
    }
}
