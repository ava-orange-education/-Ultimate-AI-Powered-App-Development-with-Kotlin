package com.orangeava.contextualaiassistant.presentation

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.orangeava.contextualaiassistant.BuildConfig
import com.orangeava.contextualaiassistant.data.GeminiRepository
import com.orangeava.contextualaiassistant.data.OpenAiRepository
import com.orangeava.contextualaiassistant.domain.AiRepository
import com.orangeava.contextualaiassistant.domain.ChatMessage
import kotlinx.coroutines.launch

class ChatViewModel(type: ModelType) : ViewModel() {

    private var repository: AiRepository = when(type) {
        ModelType.Gemini -> GeminiRepository(apiKey = BuildConfig.GEMINI_API_KEY)
        ModelType.ChatGPT -> OpenAiRepository(apiKey = BuildConfig.OPENAI_API_KEY)
        ModelType.OpenAi -> OpenAiRepository(apiKey = BuildConfig.OPENAI_API_KEY)
    }

    // The source of truth for our chat list
    private val _messages = mutableStateListOf<ChatMessage>()
    val messages: List<ChatMessage> get() = _messages

    // Loading state
    var isLoading = mutableStateOf(false)
        private set

    fun sendMessage(text: String) {
        if (text.isBlank()) return

        // Add user message to UI immediately
        _messages.add(ChatMessage(text = text, isUser = true))
        isLoading.value = true

        viewModelScope.launch {
            // Fetch response from the chosen AI Repository
            val responseText = repository.sendMessage(text)

            // Add AI response to UI
            _messages.add(ChatMessage(text = responseText, isUser = false))
            isLoading.value = false
        }
    }
}
