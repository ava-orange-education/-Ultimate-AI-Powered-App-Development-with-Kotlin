package com.orangeava.contextualaiassistant.domain

/**
 * AiRepository interface ensures our UI doesn't care if we are using
 * Gemini or ChatGPT. It just knows it can 'sendMessage'.
 */
interface AiRepository {
    suspend fun sendMessage(prompt: String, imageBitmap: Any? = null): String
}
