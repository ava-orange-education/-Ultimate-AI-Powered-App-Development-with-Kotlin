package com.orangeava.contextualaiassistant.data

import android.graphics.Bitmap
import com.orangeava.contextualaiassistant.domain.AiRepository
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

// --- DTOs (Data Transfer Objects) for OpenAI API ---
data class OpenAiRequest(val model: String, val messages: List<OpenAiMessage>)
data class OpenAiMessage(
    val role: String, // role can be "system", "user", or "assistant"
    val content: Any
) // content is Any to support Text or List (Image)

data class ContentPart(
    val type: String,
    val text: String? = null,
    val image_url: ImageUrl? = null
)

data class ImageUrl(val url: String)
data class OpenAiResponse(val choices: List<OpenAiChoice>)
data class OpenAiChoice(val message: ResponseMessage)
data class ResponseMessage(val content: String)

// --- Retrofit Interface ---
interface OpenAiApi {
    @POST("chat/completions")
    suspend fun generateResponse(
        @Header("Authorization") authHeader: String,
        @Body request: OpenAiRequest
    ): OpenAiResponse
}

// --- Repository Implementation ---
class OpenAiRepository(private val apiKey: String) : AiRepository {

    /*
    private val api: OpenAiApi by lazy {
        Retrofit.Builder()
            // USE THIS ENDPOINT FOR ChatGPT MODELS
            .baseUrl("https://api.openai.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(OpenAiApi::class.java)
    }

    override suspend fun sendMessage(prompt: String, imageBitmap: Any?): String {
        return try {
            // Check if we are sending an image
            val messageContent: Any = if (imageBitmap != null && imageBitmap is Bitmap) {
                // Convert Bitmap to Base64 for ChatGPT
                val base64Image = ImageUtils.bitmapToBase64(imageBitmap)
                listOf(
                    ContentPart(type = "text", text = prompt),
                    ContentPart(
                        type = "image_url",
                        image_url = ImageUrl("data:image/jpeg;base64,$base64Image")
                    )
                )
            } else {
                // Standard text-only message
                prompt
            }

            // Construct the Request
            val request = OpenAiRequest(
                model = "gpt-4o-mini",
                messages = listOf(
                    OpenAiMessage(role = "user", content = messageContent)
                )
            )

            // Execute Call
            val response = api.generateResponse("Bearer $apiKey", request)
            response.choices.first().message.content
        } catch (e: Exception) {
            "Error: ${e.localizedMessage}"
        }
    }
    */

    private val api: OpenAiApi by lazy {
        Retrofit.Builder()
            // USE THIS AZURE ENDPOINT FOR GITHUB MODELS
            .baseUrl("https://models.inference.ai.azure.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(OpenAiApi::class.java)
    }

    override suspend fun sendMessage(prompt: String, imageBitmap: Any?): String {
        return try {
            // Check if we are sending an image
            val messageContent: Any = if (
                imageBitmap != null
                && imageBitmap is Bitmap
            ) {
                // Convert Bitmap to Base64 for ChatGPT
                val base64Image = ImageUtils.bitmapToBase64(imageBitmap)
                listOf(
                    ContentPart(type = "text", text = prompt),
                    ContentPart(
                        type = "image_url",
                        image_url = ImageUrl(
                            "data:image/jpeg;base64," +
                                    "$base64Image"
                        )
                    )
                )
            } else {
                // Standard text-only message
                prompt
            }

            // Construct the Request
            val request = OpenAiRequest(
                model = "gpt-4o", // (Free via GitHub)
                messages = listOf(
                    OpenAiMessage(role = "user", content = messageContent),
                    // Optional: Add a system message if you want the model
                    // to behave specifically
                    // OpenAiMessage(
                    //      role = "system",
                    //      content = "You are a helpful assistant."
                    // )
                )
            )

            // Pass the GitHub Token as "Bearer <TOKEN>"
            val response = api.generateResponse("Bearer $apiKey", request)
            return response.choices.first().message.content
        } catch (e: Exception) {
            "Error: ${e.localizedMessage}"
        }
    }
}
