package com.orangeava.contextualaiassistant.domain

/**
 * Represents a single message in the chat list.
 */
data class ChatMessage(
    val text: String,
    val isUser: Boolean, // True if sent by user, False if sent by AI
    val imageUri: String? = null // Optional: to display an image if the user sent one
)
