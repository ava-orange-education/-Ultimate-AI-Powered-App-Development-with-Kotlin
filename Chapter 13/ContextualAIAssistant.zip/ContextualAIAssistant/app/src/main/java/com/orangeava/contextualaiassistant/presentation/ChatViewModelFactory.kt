package com.orangeava.contextualaiassistant.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class ChatViewModelFactory(private val type: ModelType) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ChatViewModel(type) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

sealed class ModelType {
    object Gemini : ModelType()
    object ChatGPT : ModelType()
    object OpenAi : ModelType()
}
