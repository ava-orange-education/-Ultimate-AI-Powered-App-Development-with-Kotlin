package com.orangeava.sentimentanalysis

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import org.tensorflow.lite.task.text.nlclassifier.NLClassifier
import org.tensorflow.lite.support.label.Category
import androidx.core.graphics.toColorInt

class MainActivity : AppCompatActivity() {

    private lateinit var inputText: EditText
    private lateinit var classifyButton: Button
    private lateinit var resultText: TextView
    private lateinit var analysedText: TextView
    private lateinit var progressBar: ProgressBar

    private var textClassifier: NLClassifier? = null
    private val activityScope = CoroutineScope(Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputText = findViewById(R.id.inputText)
        classifyButton = findViewById(R.id.classifyButton)
        resultText = findViewById(R.id.resultText)
        analysedText = findViewById(R.id.analysedText)
        progressBar = findViewById(R.id.progressBar)

        activityScope.launch {
            initTextClassifier()
        }

        classifyButton.setOnClickListener {
            val text = inputText.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(
                    this,
                    "Please enter some text for analysis.", Toast.LENGTH_SHORT
                ).show()
                resultText.text = ""
                return@setOnClickListener
            }
            classifySentiment(text)
        }
    }

    private suspend fun initTextClassifier() = withContext(Dispatchers.IO) {
        try {
            textClassifier = NLClassifier.createFromFile(
                this@MainActivity,
                "text_classification.tflite"
            )

            withContext(Dispatchers.Main) {
                Toast.makeText(
                    this@MainActivity,
                    "Model loaded and ready!", Toast.LENGTH_SHORT
                ).show()
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                resultText.text = "Error: Model could not be loaded."
                Toast.makeText(
                    this@MainActivity,
                    "Error loading model.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun classifySentiment(text: String) {
        if (textClassifier == null) {
            showClassificationError(
                "Model is not ready yet. Please try again in a moment.",
                null
            )
            return
        }

        progressBar.visibility = View.VISIBLE
        classifyButton.isEnabled = false

        classifyTextInBackground(text)
    }

    private fun classifyTextInBackground(text: String) {
        activityScope.launch {
            try {
                val results = withContext(Dispatchers.IO) {
                    textClassifier?.classify(text)
                }

                val topCategory: Category? = results?.maxByOrNull { it.score }

                topCategory?.let {
                    val label = it.displayName.ifEmpty { it.label }
                    val score = it.score
                    showClassificationResult(text, label, score)
                } ?: run {
                    showClassificationError("Could not determine sentiment.", null)
                }
            } catch (e: Exception) {
                showClassificationError("Text classification failed.", e)
            } finally {
                progressBar.visibility = View.GONE
                classifyButton.isEnabled = true
            }
        }
    }

    private fun showClassificationResult(input: String, label: String, score: Float) {
        inputText.text.clear()
        analysedText.text = input.trim()
        val sentimentScore = String.format("%.2f", score * 100)
        val displayResult = "$label ($sentimentScore%)"
        resultText.text = displayResult

        when (label.lowercase()) {
            "positive" -> resultText.setTextColor("#4CAF50".toColorInt()) // Green
            "negative" -> resultText.setTextColor("#F44336".toColorInt()) // Red
            else -> resultText.setTextColor("#9E9E9E".toColorInt())       // Gray
        }
    }

    private fun showClassificationError(message: String, exception: Throwable?) {
        resultText.text = "Error: $message"
        resultText.setTextColor(Color.RED)
        Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        textClassifier?.close()
        activityScope.cancel()
    }
}
