package com.orangeava.projectsmartlens.analyzer.text

import android.media.Image
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

class TextRecognitionProcessor {

    private val recognizer = TextRecognition.getClient(
        TextRecognizerOptions.DEFAULT_OPTIONS
    )

    fun buildInputImage(mediaImage: Image, rotation: Int): InputImage {
        return InputImage.fromMediaImage(mediaImage, rotation)
    }

    suspend fun extractText(inputImage: InputImage) =
        recognizer.process(inputImage).await().textBlocks
}