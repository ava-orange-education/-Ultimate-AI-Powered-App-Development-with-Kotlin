package com.orangeava.projectsmartlens.analyzer.text

import com.google.mlkit.nl.languageid.LanguageIdentification
import kotlinx.coroutines.tasks.await

class LanguageDetectionProcessor {

    private val client = LanguageIdentification.getClient()

    suspend fun identify(text: String): String {
        return client.identifyLanguage(text).await()
    }
}
