package com.orangeava.projectsmartlens.ui.translator

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import com.orangeava.projectsmartlens.model.DetectedTextBlock

/**
 * Overlay for translated text blocks.
 *
 * Note: This draws rectangles using the Rect coordinates returned by ML Kit directly.
 * If your PreviewView scales or rotates the camera image you should map these coordinates
 * into view coordinates before drawing. I can add a mapping helper if you'd like.
 */
@Composable
fun OverlayTextBlocks(
    blocks: List<DetectedTextBlock>,
    imageWidth: Int,
    imageHeight: Int,
    imageRotation: Int,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {

            if (imageWidth == 0 || imageHeight == 0) {
                return@Canvas
            }

            val rotatedImageWidth =
                if (imageRotation == 90 || imageRotation == 270) {
                    imageHeight.toFloat()
                } else {
                    imageWidth.toFloat()
                }

            val rotatedImageHeight =
                if (imageRotation == 90 || imageRotation == 270) {
                    imageWidth.toFloat()
                } else {
                    imageHeight.toFloat()
                }

            val scale = maxOf(
                size.width / rotatedImageWidth,
                size.height / rotatedImageHeight
            )

            val scaledWidth = rotatedImageWidth * scale
            val scaledHeight = rotatedImageHeight * scale

            val offsetX = (size.width - scaledWidth) / 2f
            val offsetY = (size.height - scaledHeight) / 2f

            for (b in blocks) {
                // source rect (android.graphics.Rect)
                val left =
                    b.rect.left.toFloat() * scale + offsetX

                val top =
                    b.rect.top.toFloat() * scale + offsetY

                val right =
                    b.rect.right.toFloat() * scale + offsetX

                val bottom =
                    b.rect.bottom.toFloat() * scale + offsetY

                val width = right - left
                val height = bottom - top

                // rectangle
                drawRect(
                    color = Color.Green.copy(alpha = 0.55f),
                    topLeft = Offset(left, top),
                    size = Size(width, height),
                    style = Stroke(width = 4f)
                )

                // label background (semi-transparent black rectangle under the text)
                val labelTop = top + height + 6f
                val labelHeight = 40f
                drawRect(
                    color = Color.Black.copy(alpha = 0.6f),
                    topLeft = Offset(left, labelTop),
                    size = Size(width, labelHeight)
                )

                // draw translated text using native canvas for good font control
                drawContext.canvas.nativeCanvas.apply {
                    val paint = Paint().apply {
                        color = android.graphics.Color.WHITE
                        textSize = 34f
                        isAntiAlias = true
                    }
                    // wrap/truncate could be added for long text; here we draw one line
                    drawText(
                        b.translatedText,
                        left + 8f,
                        labelTop + 28f,
                        paint
                    )
                }
            }
        }
    }
}
