package com.orangeava.projectsmartlens.model

import android.graphics.RectF

data class RectFLabel(val rect: RectF, val label: String)