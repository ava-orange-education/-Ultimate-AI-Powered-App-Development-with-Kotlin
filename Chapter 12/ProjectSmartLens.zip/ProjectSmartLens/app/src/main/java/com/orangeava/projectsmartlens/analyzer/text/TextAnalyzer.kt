package com.orangeava.projectsmartlens.analyzer.text

import android.util.Log
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.orangeava.projectsmartlens.model.DetectedTextBlock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

class TextAnalyzer(
    private val scope: CoroutineScope,
    private val onResults: (
        List<DetectedTextBlock>,
        Int,
        Int,
        Int
    ) -> Unit,
    private val textRecognition: TextRecognitionProcessor,
    private val languageDetection: LanguageDetectionProcessor,
    private val translator: TranslatorProcessor
) : ImageAnalysis.Analyzer {

    private val busy = AtomicBoolean(false)

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        if (!busy.compareAndSet(false, true)) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image ?: run {
            imageProxy.close()
            busy.set(false)
            return
        }

        val rotation = imageProxy.imageInfo.rotationDegrees
        val inputImage = textRecognition.buildInputImage(mediaImage, rotation)

        scope.launch {
            try {
                val blocks = textRecognition.extractText(inputImage)

                if (blocks.isEmpty()) {
                    onResults(
                        emptyList(),
                        imageProxy.width,
                        imageProxy.height,
                        rotation
                    )
                    return@launch
                }

                val translated = mutableListOf<DetectedTextBlock>()

                for (block in blocks) {

                    val languageCode =
                        languageDetection.identify(block.text)

                    val result = translator.translateBlock(
                        block,
                        languageCode
                    )

                    translated.add(result)
                }

                onResults(
                    translated,
                    imageProxy.width,
                    imageProxy.height,
                    rotation
                )

            } catch (e: Exception) {
                Log.e(
                    "TextAnalyzer",
                    "Text processing failed",
                    e
                )

                onResults(
                    emptyList(),
                    imageProxy.width,
                    imageProxy.height,
                    rotation
                )
            } finally {
                imageProxy.close()
                busy.set(false)
            }
        }
    }
}
