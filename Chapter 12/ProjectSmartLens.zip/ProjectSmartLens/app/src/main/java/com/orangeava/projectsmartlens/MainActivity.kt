package com.orangeava.projectsmartlens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.orangeava.projectsmartlens.theme.ProjectSmartLens
import com.orangeava.projectsmartlens.ui.CameraTabs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // request camera permission if not granted (simple flow)
        val cameraPermission = Manifest.permission.CAMERA
        if (ContextCompat.checkSelfPermission(
                this,
                cameraPermission
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(cameraPermission),
                1001
            )
        }

        setContent {
            ProjectSmartLens {
                Surface(Modifier.fillMaxSize()) {
                    CameraTabs()
                }
            }
        }
    }
}