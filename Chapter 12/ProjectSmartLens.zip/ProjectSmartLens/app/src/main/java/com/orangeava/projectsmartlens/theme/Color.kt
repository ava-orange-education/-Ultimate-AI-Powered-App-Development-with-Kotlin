package com.orangeava.projectsmartlens.theme

import androidx.compose.ui.graphics.Color

val PrimaryColor = Color(0xFF0061A4)
val SecondaryColor = Color(0xFF00A0B0)
val AccentColor = Color(0xFFFFC107)

val BackgroundLight = Color(0xFFFFFFFF)
val BackgroundDark = Color(0xFF121212)

val TextPrimary = Color(0xFF212121)
val TextSecondary = Color(0xFF757575)