package com.orangeava.projectsmartlens.ui.securityscan

import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.orangeava.projectsmartlens.analyzer.obj.ObjectAnalyzer
import com.orangeava.projectsmartlens.model.RectFLabel
import com.orangeava.projectsmartlens.ui.CameraPreviewContainer
import kotlinx.coroutines.launch
import java.util.concurrent.Executors
import kotlin.collections.iterator

@Composable
fun SecurityScanScreen() {
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(Unit) { onDispose { cameraExecutor.shutdown() } }

    val coroutineScope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current

    val boxes = remember { mutableStateListOf<RectFLabel>() }
    val counts = remember { mutableStateMapOf<String, Int>() }
    var imageWidth by remember { mutableIntStateOf(0) }
    var imageHeight by remember { mutableIntStateOf(0) }
    var imageRotation by remember { mutableIntStateOf(0) }

    Box(modifier = Modifier.fillMaxSize()) {
        CameraPreviewContainer { previewView, cameraProvider ->
            val preview = Preview.Builder()
                .build()
                .also { it.surfaceProvider = previewView.surfaceProvider }

            val resolutionSelector = ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(1280, 720),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                    )
                )
                .build()

            val imageAnalysis = ImageAnalysis.Builder()
                .setResolutionSelector(resolutionSelector)
                .setBackpressureStrategy(
                    ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
                )
                .build()

            val analyzer = ObjectAnalyzer(
                onBoxes = { list, width, height, rotation ->
                    coroutineScope.launch {
                        boxes.clear()
                        boxes.addAll(list)

                        imageWidth = width
                        imageHeight = height
                        imageRotation = rotation
                    }
                },
                onCounts = { map ->
                    coroutineScope.launch {
                        counts.clear()
                        counts.putAll(map)
                    }
                }
            )

            imageAnalysis.setAnalyzer(cameraExecutor, analyzer)

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageAnalysis
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // overlay composable (draws boxes & labels)
        OverlayBoxes(
            boxes = boxes,
            imageWidth = imageWidth,
            imageHeight = imageHeight,
            imageRotation = imageRotation
        )

        // bottom semi-transparent counts panel
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.45f))
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Live counts", color = Color.White)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                // show live counts
                for ((label, count) in counts) {
                    Text("$label: $count", color = Color.White)
                }
            }
        }
    }
}