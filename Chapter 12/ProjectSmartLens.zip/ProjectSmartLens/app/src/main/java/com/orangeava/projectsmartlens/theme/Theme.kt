package com.orangeava.projectsmartlens.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryColor,
    secondary = SecondaryColor,
    background = BackgroundDark,
    onPrimary = Color.White,
    onSecondary = Color.Black
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryColor,
    secondary = SecondaryColor,
    background = BackgroundLight,
    onPrimary = Color.White,
    onSecondary = Color.Black
)

/**
 * @title ProjectSmartLens
 * @description Defines the basic Material 3 theme for the application.
 */
@Composable
fun ProjectSmartLens(content: @Composable () -> Unit) {
    // Define a basic color scheme for the application
    val colors = lightColorScheme(
        primary = Color(0xFF4CAF50), // Green for positive/primary action
        secondary = Color(0xFF9E9E9E),
        background = Color.White,
        surface = Color.White,
        error = Color(0xFFF44336) // Red for errors/alerts
    )
    MaterialTheme(
        colorScheme = colors,
        typography = AppTypography, // Assume minimal default typography for this project
        content = content
    )
}
