package com.orangeava.projectsmartlens.ui.translator

import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.orangeava.projectsmartlens.analyzer.text.LanguageDetectionProcessor
import com.orangeava.projectsmartlens.analyzer.text.TextAnalyzer
import com.orangeava.projectsmartlens.analyzer.text.TextRecognitionProcessor
import com.orangeava.projectsmartlens.analyzer.text.TranslatorProcessor
import com.orangeava.projectsmartlens.model.DetectedTextBlock
import com.orangeava.projectsmartlens.ui.CameraPreviewContainer
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

@Composable
fun TranslateTextScreen() {
    // executor for analyzers (remember so we don't recreate on recomposition)
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    // ensure we shut it down when composable leaves composition
    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
        }
    }

    val coroutineScope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current

    // Compose state that will be updated from the analyzer callback
    val blocks = remember { mutableStateListOf<DetectedTextBlock>() }
    var imageWidth by remember {
        mutableIntStateOf(0)
    }

    var imageHeight by remember {
        mutableIntStateOf(0)
    }

    var imageRotation by remember {
        mutableIntStateOf(0)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        CameraPreviewContainer { previewView, cameraProvider ->
            val preview = Preview.Builder().build()
                .also { it.surfaceProvider = previewView.surfaceProvider }

            val resolutionSelector = ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(1280, 720),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                    )
                ).build()

            val imageAnalysis =
                ImageAnalysis.Builder().setResolutionSelector(resolutionSelector)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

            // Analyzer will call onResult with the list of DetectedTextBlock
            val analyzer = TextAnalyzer(
                scope = coroutineScope,
                onResults = { list, width, height, rotation ->
                    coroutineScope.launch {
                        blocks.clear()
                        blocks.addAll(list)

                        imageWidth = width
                        imageHeight = height
                        imageRotation = rotation
                    }
                },
                languageDetection = LanguageDetectionProcessor(),
                textRecognition = TextRecognitionProcessor(),
                translator = TranslatorProcessor()
            )

            // ImageAnalysis.setAnalyzer accepts an Executor
            imageAnalysis.setAnalyzer(cameraExecutor, analyzer)

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageAnalysis
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Overlay drawing composable (already in project)
        OverlayTextBlocks(
            blocks = blocks,
            imageWidth = imageWidth,
            imageHeight = imageHeight,
            imageRotation = imageRotation
        )
    }
}