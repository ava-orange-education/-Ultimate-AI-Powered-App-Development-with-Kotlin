package com.orangeava.projectsmartlens.model

import android.graphics.Rect

/** Data class for passing detected blocks to UI */
data class DetectedTextBlock(
    val rect: Rect,
    val rawText: String,
    val translatedText: String
)