package com.orangeava.projectsmartlens.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.orangeava.projectsmartlens.ui.securityscan.SecurityScanScreen
import com.orangeava.projectsmartlens.ui.translator.TranslateTextScreen

@Composable
fun CameraTabs() {
    var selected by remember { mutableIntStateOf(0) }
    val tabs = listOf("Translate Text", "Security Scan")

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selected) {
            tabs.forEachIndexed { i, t ->
                Tab(
                    selected = selected == i,
                    onClick = { selected = i },
                    text = { Text(t) })
            }
        }
        when (selected) {
            0 -> TranslateTextScreen()
            1 -> SecurityScanScreen()
        }
    }
}