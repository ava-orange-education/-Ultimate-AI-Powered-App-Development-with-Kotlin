package com.orangeava.projectsmartlens.ui.securityscan

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import com.orangeava.projectsmartlens.model.RectFLabel

/**
 * Overlay for object boxes and labels (Security Scan).
 *
 * Uses RectFLabel.rect (android.graphics.RectF) and RectFLabel.label.
 * Same mapping caveat as above applies.
 */
@Composable
fun OverlayBoxes(
    boxes: List<RectFLabel>,
    imageWidth: Int,
    imageHeight: Int,
    imageRotation: Int,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {

            if (imageWidth == 0 || imageHeight == 0) {
                return@Canvas
            }

            val rotatedImageWidth =
                if (imageRotation == 90 || imageRotation == 270) {
                    imageHeight.toFloat()
                } else {
                    imageWidth.toFloat()
                }

            val rotatedImageHeight =
                if (imageRotation == 90 || imageRotation == 270) {
                    imageWidth.toFloat()
                } else {
                    imageHeight.toFloat()
                }

            val scale = maxOf(
                size.width / rotatedImageWidth,
                size.height / rotatedImageHeight
            )

            val scaledWidth = rotatedImageWidth * scale
            val scaledHeight = rotatedImageHeight * scale

            val offsetX = (size.width - scaledWidth) / 2f
            val offsetY = (size.height - scaledHeight) / 2f

            for (b in boxes) {

                val left = b.rect.left * scale + offsetX
                val top = b.rect.top * scale + offsetY
                val right = b.rect.right * scale + offsetX
                val bottom = b.rect.bottom * scale + offsetY

                val width = right - left
                val height = bottom - top

                drawRect(
                    color = Color.Red.copy(alpha = 0.55f),
                    topLeft = Offset(left, top),
                    size = Size(width, height),
                    style = Stroke(width = 4f)
                )

                drawContext.canvas.nativeCanvas.apply {
                    val paint = Paint().apply {
                        color = android.graphics.Color.WHITE
                        textSize = 34f
                        isAntiAlias = true
                    }

                    drawText(
                        b.label,
                        left + 8f,
                        top + 34f,
                        paint
                    )
                }
            }
        }
    }
}