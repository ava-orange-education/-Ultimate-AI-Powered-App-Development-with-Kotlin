package com.orangeava.projectsmartlens.analyzer.text

import android.graphics.Rect
import android.util.Log
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.orangeava.projectsmartlens.model.DetectedTextBlock
import com.google.mlkit.vision.text.Text
import kotlinx.coroutines.tasks.await

class TranslatorProcessor {
    private val translators = mutableMapOf<String, Translator>()

    // Reuse same translator
    private fun getTranslator(
        sourceLang: String,
        targetLang: String
    ): Translator {

        val key = "$sourceLang-$targetLang"

        return translators.getOrPut(key) {

            val options = TranslatorOptions.Builder()
                .setSourceLanguage(sourceLang)
                .setTargetLanguage(targetLang)
                .build()

            Translation.getClient(options)
        }
    }

    suspend fun translateBlock(
        block: Text.TextBlock,
        sourceLang: String,
        // Hindi is used as the target language in this example.
        // TODO: You should extend this project and Implement a
        //  language selector UI to allow users to choose the
        //  target language and pass that to targetLang.
        targetLang: String = TranslateLanguage.HINDI
    ): DetectedTextBlock {

        if (sourceLang == "und" ||
            sourceLang == targetLang ||
            TranslateLanguage.fromLanguageTag(sourceLang) == null
        ) {
            return DetectedTextBlock(
                block.boundingBox ?: Rect(),
                block.text,
                block.text
            )
        }

        val supportedSourceLang =
            TranslateLanguage.fromLanguageTag(sourceLang)
                ?: return DetectedTextBlock(
                    block.boundingBox ?: Rect(),
                    block.text,
                    block.text
                )

        val translator = getTranslator(
            supportedSourceLang,
            targetLang
        )

        translator.downloadModelIfNeeded().await()

        return try {

            val translated =
                translator.translate(block.text).await()

            DetectedTextBlock(
                block.boundingBox ?: Rect(),
                block.text,
                translated
            )

        } catch (e: Exception) {
            Log.e(
                "TranslatorProcessor",
                "Translation failed for language: $sourceLang",
                e
            )

            DetectedTextBlock(
                block.boundingBox ?: Rect(),
                block.text,
                block.text
            )
        }
    }
}
