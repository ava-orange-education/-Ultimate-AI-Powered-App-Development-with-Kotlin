package com.orangeava.avasentimentanalysisproject.factory

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.orangeava.avasentimentanalysisproject.sentiment.ui.SentimentViewModel

/**
 * A custom ViewModelProvider.Factory to create SentimentViewModel.
 *
 * This factory is necessary because SentimentViewModel depends on SentimentAnalyzer,
 * which in turn requires a Context. The default ViewModel factory doesn't know
 * how to provide these dependencies.
 *
 * @param context The application context, needed to create the SentimentAnalyzer.
 */
class ViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SentimentViewModel::class.java)) {
            // We pass the context to the ViewModel, which will create its own analyzer.
            return SentimentViewModel(context.applicationContext) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
