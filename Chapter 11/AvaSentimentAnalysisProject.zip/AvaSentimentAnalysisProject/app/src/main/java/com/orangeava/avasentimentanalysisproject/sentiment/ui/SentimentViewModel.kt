package com.orangeava.avasentimentanalysisproject.sentiment.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.orangeava.avasentimentanalysisproject.sentiment.data.analyzer.SentimentAnalyzer
import com.orangeava.avasentimentanalysisproject.sentiment.data.model.SentimentResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class AnalysisUiState {
    object Idle : AnalysisUiState()
    object Loading : AnalysisUiState()
    data class Success(val result: SentimentResult) : AnalysisUiState()
    data class Error(val message: String) : AnalysisUiState()
}

class SentimentViewModel(private val context: Context) : ViewModel() {

    private val _uiState = MutableStateFlow<AnalysisUiState>(AnalysisUiState.Idle)
    val uiState: StateFlow<AnalysisUiState> = _uiState.asStateFlow()

    private var sentimentAnalyzer: SentimentAnalyzer? = null

    init {
        // Asynchronously initialize the analyzer as soon as the ViewModel is created
        viewModelScope.launch(Dispatchers.IO) {
            try {
                sentimentAnalyzer = SentimentAnalyzer.create(context)
            } catch (e: Exception) {
                // Handle initialization errors
                _uiState.value = AnalysisUiState.Error(
                    "Failed to load model: ${e.message}"
                )
            }
        }
    }

    fun analyzeText(text: String) {
        if (text.isBlank()) {
            _uiState.value = AnalysisUiState.Error("Text cannot be blank.")
            return
        }

        // Ensure the analyzer is loaded before proceeding
        if (sentimentAnalyzer == null) {
            _uiState.value = AnalysisUiState.Error("Model not ready. Please wait.")
            return
        }

        _uiState.value = AnalysisUiState.Loading

        viewModelScope.launch {
            val score = withContext(Dispatchers.IO) {
                sentimentAnalyzer?.predictScore(text)
            }

            // Sometime training gets reversed and model returns
            // positive sentiment for negative and vice versa.
            // So form code you can handle is as 1f - (score ?: 0f)
            //val adjustedScore = 1f - (score ?: 0f)

            val adjustedScore = score ?: 0f
            val sentimentResult = when {
                adjustedScore >= 0.6f -> {
                    SentimentResult("Positive", adjustedScore, "😄")
                }

                adjustedScore > 0.4f -> {
                    // Captures anything between 0.4 and 0.6 (e.g., 0.5)
                    SentimentResult("Uncertain", adjustedScore, "😐")
                }

                else -> {
                    // Everything else (<= 0.4f) is Negative.
                    SentimentResult("Negative", adjustedScore, "😢")
                }
            }
            _uiState.value = AnalysisUiState.Success(sentimentResult)
        }
    }

    fun clearState() {
        _uiState.value = AnalysisUiState.Idle
    }

    override fun onCleared() {
        super.onCleared()
        sentimentAnalyzer?.close()
    }
}
