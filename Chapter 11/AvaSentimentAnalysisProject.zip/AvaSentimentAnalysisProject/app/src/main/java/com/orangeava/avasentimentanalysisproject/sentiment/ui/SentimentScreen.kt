package com.orangeava.avasentimentanalysisproject.sentiment.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.orangeava.avasentimentanalysisproject.sentiment.data.model.SentimentResult
import com.orangeava.avasentimentanalysisproject.ui.theme.AvaSentimentAnalysisProjectTheme

@Composable
fun SentimentAnalysisScreen(viewModel: SentimentViewModel = viewModel()) {
    var inputText by remember { mutableStateOf("") }
    val uiState by viewModel.uiState.collectAsState()
    val isAnalyzing = uiState is AnalysisUiState.Loading

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(80.dp))
        Text(
            text = "Type your movie review for Sentiment Analysis",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        OutlinedTextField(
            value = inputText,
            onValueChange = {
                inputText = it
                viewModel.clearState()
            },
            label = { Text("Enter your text here") },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp, max = 240.dp),
            keyboardOptions = KeyboardOptions.Default.copy(
                imeAction = ImeAction.Done
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { viewModel.analyzeText(inputText) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(12.dp),
            enabled = !isAnalyzing
        ) {
            if (isAnalyzing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.dp
                )
            } else {
                Text("Analyze Sentiment", fontSize = 16.sp)
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        AnimatedVisibility(visible = uiState !is AnalysisUiState.Idle) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    when (uiState) {
                        is AnalysisUiState.Loading -> {
                            Text(
                                "Analyzing...",
                                style = MaterialTheme.typography.bodyLarge
                            )
                            CircularProgressIndicator(
                                modifier = Modifier.padding(top = 16.dp)
                            )
                        }

                        is AnalysisUiState.Success -> {
                            val result = (uiState as AnalysisUiState.Success).result
                            SentimentResultCard(result)
                        }

                        is AnalysisUiState.Error -> {
                            Text(
                                "⚠️ Error: ${
                                    (uiState as AnalysisUiState.Error).message
                                }",
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodyLarge,
                                textAlign = TextAlign.Center
                            )
                        }

                        is AnalysisUiState.Idle -> {
                            /* Nothing to show, handled by AnimatedVisibility */
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SentimentResultCard(result: SentimentResult) {
    val resultColor = when {
        result.score >= 0.6f -> Color(0xFF2E7D32) // Green for positive
        result.score <= 0.4f -> Color(0xFFC62828) // Red for negative
        else -> MaterialTheme.colorScheme.onSurface // Uncertain
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = result.emoji,
            fontSize = 60.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text(
            text = result.sentiment,
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
            color = resultColor,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        Text(
            text = "Score: %.1f".format(result.score * 100),
            style = MaterialTheme.typography.bodyLarge,
            color = resultColor.copy(alpha = 0.8f)
        )
    }
}

@Preview(name = "Positive Result", showBackground = true)
@Composable
fun Preview_SentimentResultCard_Positive() {
    // Wrap the preview in your app's theme to ensure consistent styling
    AvaSentimentAnalysisProjectTheme {
        SentimentResultCard(
            result = SentimentResult(
                score = 0.92f,
                sentiment = "Positive",
                emoji = "😄"
            )
        )
    }
}

@Preview(name = "Negative Result", showBackground = true)
@Composable
fun Preview_SentimentResultCard_Negative() {
    AvaSentimentAnalysisProjectTheme {
        SentimentResultCard(
            result = SentimentResult(
                score = 0.15f,
                sentiment = "Negative",
                emoji = "😠"
            )
        )
    }
}

@Preview(name = "Uncertain Result", showBackground = true)
@Composable
fun Preview_SentimentResultCard_Uncertain() {
    AvaSentimentAnalysisProjectTheme {
        SentimentResultCard(
            result = SentimentResult(
                score = 0.45f,
                sentiment = "Uncertain",
                emoji = "😐"
            )
        )
    }
}