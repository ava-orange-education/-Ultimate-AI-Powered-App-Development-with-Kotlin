package com.orangeava.avasentimentanalysisproject.sentiment.data.analyzer

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class SentimentAnalyzer private constructor(
    private val context: Context,
    private val interpreter: Interpreter,
    private val wordIndex: Map<String, Int>
) {
    private val inputLength: Int
    private val unkIndex: Int
    private val maxVocabSize = 10000

    init {
        val inputShape = interpreter.getInputTensor(0).shape()
        inputLength = inputShape[1]

        // The standard index for <UNK> is typically 2.
        unkIndex = wordIndex["<UNK>"] ?: 2

        Log.d(
            "SentimentAnalyzer",
            "Model initialized | Input length: $inputLength | " +
                    "Max vocab size: $maxVocabSize | unkIndex: $unkIndex"
        )
    }

    // Static builder function to handle asynchronous loading
    companion object {
        suspend fun create(context: Context): SentimentAnalyzer {
            val wordIndex = loadWordIndex(context)
            val modelFile = loadModelFile(
                context,
                "models/sentiment_model_fp16.tflite"
            )
            val interpreter = Interpreter(modelFile)
            return SentimentAnalyzer(context, interpreter, wordIndex)
        }

        @Throws(IOException::class)
        private fun loadModelFile(context: Context, fileName: String): MappedByteBuffer {
            val fileDescriptor = context.assets.openFd(fileName)
            FileInputStream(fileDescriptor.fileDescriptor).use { input ->
                val fileChannel = input.channel
                val startOffset = fileDescriptor.startOffset
                val declaredLength = fileDescriptor.declaredLength
                return fileChannel.map(
                    FileChannel.MapMode.READ_ONLY,
                    startOffset,
                    declaredLength
                )
            }
        }

        private fun loadWordIndex(context: Context): Map<String, Int> {
            val jsonString = context.assets.open(
                "models/word_index.json"
            ).bufferedReader().use { it.readText() }
            val type = object : TypeToken<Map<String, Int>>() {}.type
            return Gson().fromJson(jsonString, type)
        }
    }

    fun predictScore(text: String): Float {
        val inputBuffer = textToByteBuffer(text)
        val outputShape = interpreter.getOutputTensor(0).shape()
        val outputBuffer = Array(outputShape[0]) { FloatArray(outputShape[1]) }
        interpreter.run(inputBuffer, outputBuffer)
        return outputBuffer[0][0]
    }

    private fun textToByteBuffer(text: String): ByteBuffer {
        val tokens = preprocessText(text)
        val bufferSize = inputLength * 4
        val buffer = ByteBuffer.allocateDirect(bufferSize)
        buffer.order(ByteOrder.nativeOrder())
        val inputType = interpreter.getInputTensor(0).dataType()
        val truncatedTokens = tokens.take(inputLength)

        for (i in 0 until inputLength) {
            val rawIndex = if (i < truncatedTokens.size) {
                wordIndex[truncatedTokens[i]] ?: unkIndex
            } else 0

            val tokenIndex = if (rawIndex >= maxVocabSize) unkIndex else rawIndex
            val safeIndex = tokenIndex.coerceIn(0, maxVocabSize - 1)

            when (inputType) {
                DataType.FLOAT32 -> buffer.putFloat(safeIndex.toFloat())
                DataType.INT32 -> buffer.putInt(safeIndex)
                else -> throw IllegalArgumentException("Unsupported input type: $inputType")
            }
        }

        buffer.rewind()
        return buffer
    }

    private fun preprocessText(text: String): List<String> {
        return text.lowercase()
            .replace(Regex("[^a-zA-Z\\s]"), "")
            .split("\\s+".toRegex())
            .filter { it.isNotBlank() }
    }

    fun close() {
        interpreter.close()
    }
}