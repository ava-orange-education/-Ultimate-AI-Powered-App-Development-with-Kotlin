package com.orangeava.avasentimentanalysisproject.sentiment.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.orangeava.avasentimentanalysisproject.factory.ViewModelFactory
import com.orangeava.avasentimentanalysisproject.ui.theme.AvaSentimentAnalysisProjectTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AvaSentimentAnalysisProjectTheme {
                // 1. Get the application context
                val context = LocalContext.current.applicationContext

                // 2. Create an instance of your custom factory
                val viewModelFactory = remember { ViewModelFactory(context) }

                // 3. Provide the factory when creating the ViewModel
                val sentimentViewModel: SentimentViewModel = viewModel(
                    factory = viewModelFactory
                )

                // Call the screen, passing the ViewModel directly.
                SentimentAnalysisScreen(viewModel = sentimentViewModel)
            }
        }
    }
}