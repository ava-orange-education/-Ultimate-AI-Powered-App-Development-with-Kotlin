package com.orangeava.avasentimentanalysisproject.sentiment.data.model

// Define a simple data class for the sentiment result
data class SentimentResult(
    val sentiment: String, // e.g., "Positive", "Negative", "Uncertain"
    val score: Float,      // e.g., 0.8f, -0.5f, 0.1f
    val emoji: String      // e.g., "😄", "😢", "😐"
)